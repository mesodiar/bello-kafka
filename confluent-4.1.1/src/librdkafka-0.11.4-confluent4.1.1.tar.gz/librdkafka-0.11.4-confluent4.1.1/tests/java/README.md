# Misc Java tools

## Murmur2 CLI

Build:

    $ KAFKA_DIR=/your/kafka-build-dir make

Run:

    $ KAFKA_DIR=/your/kafka-build-dir ./run-class.sh Murmur2Cli "a sentence" and a word

